package com.blockblastai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockBlastAccessibilityService : AccessibilityService() {

    companion object {
        const val BLOCK_BLAST_PACKAGE = "com.tge.blockspu"
        const val ACTION_PERFORM_TAP = "com.blockblastai.PERFORM_TAP"
        const val ACTION_PERFORM_DRAG = "com.blockblastai.PERFORM_DRAG"
        const val EXTRA_X = "x"
        const val EXTRA_Y = "y"
        const val EXTRA_TO_X = "to_x"
        const val EXTRA_TO_Y = "to_y"

        var instance: BlockBlastAccessibilityService? = null
        var isBlockBlastActive = false
        var onGameDetected: (() -> Unit)? = null
        var onGameLeft: (() -> Unit)? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return

        val pkg = event.packageName?.toString() ?: return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                val wasActive = isBlockBlastActive
                isBlockBlastActive = pkg == BLOCK_BLAST_PACKAGE

                if (!wasActive && isBlockBlastActive) {
                    handler.post { onGameDetected?.invoke() }
                } else if (wasActive && !isBlockBlastActive) {
                    handler.post { onGameLeft?.invoke() }
                }
            }
        }
    }

    override fun onInterrupt() {
        instance = null
        isBlockBlastActive = false
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // ---- Gesture Simulation ----

    /**
     * Simulate a tap at screen coordinates (x, y)
     */
    fun performTap(x: Float, y: Float, onDone: (() -> Unit)? = null) {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 100)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                handler.post { onDone?.invoke() }
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                handler.post { onDone?.invoke() }
            }
        }, null)
    }

    /**
     * Simulate a drag from (fromX, fromY) to (toX, toY)
     * Used to drag a piece from the piece selector to the grid position
     */
    fun performDrag(
        fromX: Float, fromY: Float,
        toX: Float, toY: Float,
        duration: Long = 300,
        onDone: (() -> Unit)? = null
    ) {
        val path = Path().apply {
            moveTo(fromX, fromY)
            lineTo(toX, toY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                handler.post { onDone?.invoke() }
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                handler.post { onDone?.invoke() }
            }
        }, null)
    }

    /**
     * Get screen bounds of a specific node by content description
     */
    fun findNodeBounds(contentDesc: String): Rect? {
        val root = rootInActiveWindow ?: return null
        return findNodeRecursive(root, contentDesc)?.let { node ->
            val rect = Rect()
            node.getBoundsInScreen(rect)
            node.recycle()
            rect
        }
    }

    private fun findNodeRecursive(node: AccessibilityNodeInfo, desc: String): AccessibilityNodeInfo? {
        if (node.contentDescription?.contains(desc, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeRecursive(child, desc)
            if (result != null) return result
            child.recycle()
        }
        return null
    }
}

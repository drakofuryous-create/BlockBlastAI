package com.blockblastai

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 100
        private const val REQUEST_OVERLAY = 101
    }

    private lateinit var accessibilityStatus: TextView
    private lateinit var overlayStatus: TextView
    private lateinit var captureStatus: TextView
    private lateinit var btnLaunch: Button
    private lateinit var btnStop: Button

    private var mediaProjectionResultCode: Int = -1
    private var mediaProjectionResultData: Intent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        accessibilityStatus = findViewById(R.id.accessibilityStatus)
        overlayStatus = findViewById(R.id.overlayStatus)
        captureStatus = findViewById(R.id.captureStatus)
        btnLaunch = findViewById(R.id.btnLaunch)
        btnStop = findViewById(R.id.btnStop)

        // Accessibility permission
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            openAccessibilitySettings()
        }

        // Overlay permission
        findViewById<Button>(R.id.btnOverlay).setOnClickListener {
            requestOverlayPermission()
        }

        // Screen capture permission
        findViewById<Button>(R.id.btnCapture).setOnClickListener {
            requestScreenCapture()
        }

        // Launch AI
        btnLaunch.setOnClickListener {
            launchAI()
        }

        // Stop AI
        btnStop.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            updateUI()
        }
    }

    override fun onResume() {
        super.onResume()
        updateUI()
    }

    private fun updateUI() {
        val accessOk = isAccessibilityEnabled()
        val overlayOk = Settings.canDrawOverlays(this)
        val captureOk = mediaProjectionResultCode != -1 && mediaProjectionResultData != null

        // Accessibility
        accessibilityStatus.text = if (accessOk) "● ACTIVÉ" else "● NON ACTIVÉ"
        accessibilityStatus.setTextColor(
            ContextCompat.getColor(this, if (accessOk) R.color.green_ok else R.color.red_error)
        )

        // Overlay
        overlayStatus.text = if (overlayOk) "● ACTIVÉ" else "● NON ACTIVÉ"
        overlayStatus.setTextColor(
            ContextCompat.getColor(this, if (overlayOk) R.color.green_ok else R.color.red_error)
        )

        // Capture
        captureStatus.text = if (captureOk) "● ACTIVÉ" else "● NON ACTIVÉ"
        captureStatus.setTextColor(
            ContextCompat.getColor(this, if (captureOk) R.color.green_ok else R.color.red_error)
        )

        // Enable launch button only if all permissions granted
        val allGranted = accessOk && overlayOk && captureOk
        btnLaunch.isEnabled = allGranted
        btnLaunch.backgroundTintList = ContextCompat.getColorStateList(
            this,
            if (allGranted) R.color.accent_pink else R.color.border_color
        )

        // Show stop button state
        val serviceRunning = OverlayService.isRunning
        btnStop.isEnabled = serviceRunning
        btnStop.backgroundTintList = ContextCompat.getColorStateList(
            this,
            if (serviceRunning) R.color.red_error else R.color.border_color
        )
    }

    // ---- Permission Requests ----

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY)
        }
    }

    private fun requestScreenCapture() {
        val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(
            projectionManager.createScreenCaptureIntent(),
            REQUEST_MEDIA_PROJECTION
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQUEST_MEDIA_PROJECTION -> {
                if (resultCode == Activity.RESULT_OK && data != null) {
                    mediaProjectionResultCode = resultCode
                    mediaProjectionResultData = data
                }
            }
        }
        updateUI()
    }

    // ---- Launch AI ----

    private fun launchAI() {
        val intent = Intent(this, OverlayService::class.java).apply {
            putExtra(OverlayService.EXTRA_RESULT_CODE, mediaProjectionResultCode)
            putExtra(OverlayService.EXTRA_RESULT_DATA, mediaProjectionResultData)
        }
        ContextCompat.startForegroundService(this, intent)
        updateUI()

        // Hint user to switch to Block Blast
        android.widget.Toast.makeText(
            this,
            "✓ AI lancée ! Ouvre Block Blast maintenant.",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    // ---- Helpers ----

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.contains(
            "$packageName/${BlockBlastAccessibilityService::class.java.name}"
        )
    }
}

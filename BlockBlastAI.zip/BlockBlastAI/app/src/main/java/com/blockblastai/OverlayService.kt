package com.blockblastai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class OverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "BlockBlastAI"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        var isRunning = false
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var screenCaptureManager: ScreenCaptureManager? = null
    private var mediaProjection: MediaProjection? = null

    private val handler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var isAIPlaying = false
    private var aiSpeed = 5  // 1-10
    private var movesCount = 0
    private var linesCount = 0
    private var aiJob: Job? = null

    // Current game state
    private var currentBoard = Array(8) { IntArray(8) }
    private var currentPieces = listOf<Piece?>(null, null, null)

    // Layout params for overlay
    private val overlayParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.END
        x = 8
        y = 120
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        setupAccessibilityCallbacks()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)

        if (resultCode != -1 && resultData != null) {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            screenCaptureManager = ScreenCaptureManager(this, mediaProjection!!)
            screenCaptureManager?.start()
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        isAIPlaying = false
        aiJob?.cancel()
        scope.cancel()
        removeOverlay()
        screenCaptureManager?.stop()
        mediaProjection?.stop()
    }

    // ---- Overlay Setup ----

    private fun setupAccessibilityCallbacks() {
        BlockBlastAccessibilityService.onGameDetected = {
            handler.postDelayed({ showOverlay() }, 500)
        }
        BlockBlastAccessibilityService.onGameLeft = {
            stopAI()
        }

        // If Block Blast is already open
        if (BlockBlastAccessibilityService.isBlockBlastActive) {
            handler.postDelayed({ showOverlay() }, 500)
        }
    }

    private fun showOverlay() {
        if (overlayView != null) return

        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_panel, null)

        setupOverlayInteractions(overlayView!!)

        try {
            windowManager.addView(overlayView, overlayParams)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }

    private fun setupOverlayInteractions(view: View) {
        // Close button
        view.findViewById<TextView>(R.id.btnClose).setOnClickListener {
            stopAI()
            removeOverlay()
        }

        // Toggle AI button
        view.findViewById<Button>(R.id.btnToggleAI).setOnClickListener {
            if (isAIPlaying) stopAI() else startAI()
        }

        // Speed seekbar
        view.findViewById<SeekBar>(R.id.speedBar).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                    aiSpeed = progress + 1
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            }
        )

        // Drag to move overlay
        var initX = 0; var initY = 0; var initTX = 0f; var initTY = 0f

        view.findViewById<View>(R.id.dragHandle).setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = overlayParams.x; initY = overlayParams.y
                    initTX = event.rawX; initTY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    overlayParams.x = initX + (initTX - event.rawX).toInt()
                    overlayParams.y = initY + (event.rawY - initTY).toInt()
                    try { windowManager.updateViewLayout(overlayView, overlayParams) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    private fun updateOverlayStatus(status: String, nextMove: String = "") {
        handler.post {
            val v = overlayView ?: return@post
            v.findViewById<TextView>(R.id.tvStatus).text = status
            v.findViewById<TextView>(R.id.tvMoves).text = movesCount.toString()
            v.findViewById<TextView>(R.id.tvLines).text = linesCount.toString()
            if (nextMove.isNotEmpty()) {
                v.findViewById<TextView>(R.id.tvNextMove).text = nextMove
            }
        }
    }

    // ---- AI Logic ----

    private fun startAI() {
        isAIPlaying = true
        val btn = overlayView?.findViewById<Button>(R.id.btnToggleAI)
        btn?.text = "⏸ PAUSE"
        btn?.backgroundTintList = android.content.res.ColorStateList.valueOf(
            android.graphics.Color.parseColor("#FFBE0B")
        )
        updateOverlayStatus("● ANALYSE EN COURS...")

        aiJob = scope.launch {
            runAILoop()
        }
    }

    private fun stopAI() {
        isAIPlaying = false
        aiJob?.cancel()
        val btn = overlayView?.findViewById<Button>(R.id.btnToggleAI)
        handler.post {
            btn?.text = "▶ JOUER"
            btn?.backgroundTintList = android.content.res.ColorStateList.valueOf(
                android.graphics.Color.parseColor("#FF006E")
            )
        }
        updateOverlayStatus("● EN ATTENTE")
    }

    private suspend fun runAILoop() {
        while (isAIPlaying && isActive) {
            val service = BlockBlastAccessibilityService.instance

            if (service == null || !BlockBlastAccessibilityService.isBlockBlastActive) {
                updateOverlayStatus("● BLOCK BLAST NON DÉTECTÉ")
                delay(1000)
                continue
            }

            // Capture and analyze screen
            val bitmap = withContext(Dispatchers.IO) {
                screenCaptureManager?.captureScreen()
            }

            if (bitmap == null) {
                updateOverlayStatus("● CAPTURE IMPOSSIBLE")
                delay(500)
                continue
            }

            val region = screenCaptureManager!!.estimateGridRegion()

            // Parse board
            currentBoard = withContext(Dispatchers.Default) {
                screenCaptureManager!!.parseBoardFromBitmap(bitmap, region)
            }
            bitmap.recycle()

            // Build pieces (simplified: generate 3 random pieces since we can't
            // easily parse them from screen without ML — real calibration needed)
            currentPieces = generatePiecesForCurrentState()

            // Find best move
            val bestMove = withContext(Dispatchers.Default) {
                AIEngine.getBestMove(currentBoard, currentPieces)
            }

            if (bestMove == null) {
                updateOverlayStatus("● AUCUN COUP POSSIBLE")
                delay(1000)
                continue
            }

            // Get screen coordinates for the target cell
            val (targetX, targetY) = screenCaptureManager!!.cellToScreenCoords(
                bestMove.row, bestMove.col, region
            )

            // Get piece source position (from bottom piece selector)
            val piecePositions = screenCaptureManager!!.getPieceSelectorPositions()
            val (srcX, srcY) = piecePositions[bestMove.pieceIndex]

            updateOverlayStatus(
                "● JOUE PIÈCE ${bestMove.pieceIndex + 1}",
                "→ Cellule (${bestMove.row},${bestMove.col})"
            )

            // Execute drag gesture: from piece selector → target grid cell
            val dragDone = CompletableDeferred<Unit>()
            handler.post {
                service.performDrag(srcX, srcY, targetX, targetY, 250) {
                    dragDone.complete(Unit)
                }
            }
            dragDone.await()

            movesCount++

            // Update stats
            val prevBoard = currentBoard.map { it.copyOf() }.toTypedArray()
            delay(300)

            // Recapture to count cleared lines
            val newBitmap = withContext(Dispatchers.IO) {
                screenCaptureManager?.captureScreen()
            }
            if (newBitmap != null) {
                val newBoard = withContext(Dispatchers.Default) {
                    screenCaptureManager!!.parseBoardFromBitmap(newBitmap, region)
                }
                // Heuristic: count cleared lines by comparing filled cells
                val prevFilled = prevBoard.sumOf { row -> row.count { it != 0 } }
                val newFilled = newBoard.sumOf { row -> row.count { it != 0 } }
                val piece = currentPieces[bestMove.pieceIndex]
                val pieceCells = piece?.cells?.size ?: 0
                val clearedCells = (prevFilled + pieceCells) - newFilled
                if (clearedCells >= 8) linesCount += clearedCells / 8
                newBitmap.recycle()
            }

            // Delay between moves based on speed (1=slow, 10=fast)
            val delayMs = (1100L - aiSpeed * 100L).coerceAtLeast(100L)
            delay(delayMs)
        }
    }

    /**
     * Generate representative pieces. In a production app this would use
     * image recognition to detect the actual pieces shown on screen.
     * For now we use a smart fallback: try common pieces that are likely to fit.
     */
    private fun generatePiecesForCurrentState(): List<Piece?> {
        val commonPieces = listOf(
            Piece(arrayOf(intArrayOf(1,1), intArrayOf(1,1))),     // 2x2 square
            Piece(arrayOf(intArrayOf(1,1,1))),                      // horizontal triple
            Piece(arrayOf(intArrayOf(1), intArrayOf(1), intArrayOf(1))), // vertical triple
            Piece(arrayOf(intArrayOf(1,1,1,1))),                   // horizontal quad
            Piece(arrayOf(intArrayOf(1,1), intArrayOf(1,0))),      // L-shape
            Piece(arrayOf(intArrayOf(1,0), intArrayOf(1,1))),      // J-shape
            Piece(arrayOf(intArrayOf(1))),                          // single
            Piece(arrayOf(intArrayOf(1,1,1), intArrayOf(0,0,1))),  // L-long
        )
        // Return 3 varied pieces
        return listOf(
            commonPieces.random(),
            commonPieces.random(),
            commonPieces.random()
        )
    }

    // ---- Foreground Notification ----

    private fun startForegroundNotification() {
        val channel = NotificationChannel(
            CHANNEL_ID, "Block Blast AI",
            NotificationManager.IMPORTANCE_LOW
        ).apply { description = "AI overlay service" }

        val notifManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notifManager.createNotificationChannel(channel)

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Block Blast AI actif")
            .setContentText("Ouvre Block Blast pour que l'IA joue automatiquement")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(1, notification)
    }
}

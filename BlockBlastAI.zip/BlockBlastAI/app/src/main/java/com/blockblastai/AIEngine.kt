package com.blockblastai

// ============================================================
// Data Models
// ============================================================

data class Piece(
    val shape: Array<IntArray>,
    val colorHint: Int = 0
) {
    val rows get() = shape.size
    val cols get() = shape[0].size
    val cells: List<Pair<Int,Int>> get() {
        val list = mutableListOf<Pair<Int,Int>>()
        for (r in shape.indices) for (c in shape[r].indices) {
            if (shape[r][c] == 1) list.add(Pair(r, c))
        }
        return list
    }
}

data class Move(
    val pieceIndex: Int,
    val row: Int,
    val col: Int,
    val score: Double
)

// ============================================================
// Block Blast AI Engine
// ============================================================
object AIEngine {

    private const val GRID = 8

    // ---- Scoring weights ----
    private const val W_LINES_CLEARED   =  500.0
    private const val W_HOLES           = -40.0
    private const val W_BUMPINESS       = -8.0
    private const val W_MAX_HEIGHT      = -12.0
    private const val W_NEAR_COMPLETE   =  25.0
    private const val W_BOTTOM_DENSITY  =  3.0
    private const val W_CELLS_PLACED    =  2.0

    fun findBestMoves(board: Array<IntArray>, pieces: List<Piece?>): List<Move> {
        val moves = mutableListOf<Move>()

        pieces.forEachIndexed { pieceIndex, piece ->
            piece ?: return@forEachIndexed

            var bestScore = Double.NEGATIVE_INFINITY
            var bestMove: Move? = null

            val maxRow = GRID - piece.rows
            val maxCol = GRID - piece.cols

            for (r in 0..maxRow) {
                for (c in 0..maxCol) {
                    if (!canPlace(board, piece, r, c)) continue

                    val testBoard = simulatePlacement(board, piece, r, c)
                    val cleared = simulateClear(testBoard)
                    val eval = evaluateBoard(testBoard, cleared, piece.cells.size)

                    if (eval > bestScore) {
                        bestScore = eval
                        bestMove = Move(pieceIndex, r, c, eval)
                    }
                }
            }

            bestMove?.let { moves.add(it) }
        }

        // Return moves sorted by best score — pick highest
        return moves.sortedByDescending { it.score }
    }

    fun getBestMove(board: Array<IntArray>, pieces: List<Piece?>): Move? {
        return findBestMoves(board, pieces).firstOrNull()
    }

    fun canPlace(board: Array<IntArray>, piece: Piece, row: Int, col: Int): Boolean {
        for ((r, c) in piece.cells) {
            val nr = row + r
            val nc = col + c
            if (nr < 0 || nr >= GRID || nc < 0 || nc >= GRID) return false
            if (board[nr][nc] != 0) return false
        }
        return true
    }

    private fun simulatePlacement(board: Array<IntArray>, piece: Piece, row: Int, col: Int): Array<IntArray> {
        val copy = board.map { it.copyOf() }.toTypedArray()
        for ((r, c) in piece.cells) {
            copy[row + r][col + c] = 1
        }
        return copy
    }

    private fun simulateClear(board: Array<IntArray>): Int {
        var cleared = 0
        // Rows
        for (r in 0 until GRID) {
            if (board[r].all { it != 0 }) {
                board[r] = IntArray(GRID) { 0 }
                cleared++
            }
        }
        // Cols
        for (c in 0 until GRID) {
            if ((0 until GRID).all { board[it][c] != 0 }) {
                for (r in 0 until GRID) board[r][c] = 0
                cleared++
            }
        }
        return cleared
    }

    private fun evaluateBoard(board: Array<IntArray>, linesCleared: Int, cellsPlaced: Int): Double {
        var score = 0.0

        // Lines cleared bonus
        score += linesCleared * W_LINES_CLEARED

        // Multi-line bonus
        if (linesCleared >= 2) score += linesCleared * linesCleared * 100

        // Holes
        var holes = 0
        for (c in 0 until GRID) {
            var foundFilled = false
            for (r in 0 until GRID) {
                if (board[r][c] != 0) foundFilled = true
                else if (foundFilled) holes++
            }
        }
        score += holes * W_HOLES

        // Column heights
        val heights = IntArray(GRID)
        for (c in 0 until GRID) {
            for (r in 0 until GRID) {
                if (board[r][c] != 0) {
                    heights[c] = GRID - r
                    break
                }
            }
        }

        // Max height
        val maxH = heights.maxOrNull() ?: 0
        score += maxH * W_MAX_HEIGHT

        // Bumpiness
        var bumpiness = 0
        for (c in 0 until GRID - 1) {
            bumpiness += Math.abs(heights[c] - heights[c + 1])
        }
        score += bumpiness * W_BUMPINESS

        // Near complete rows/cols
        var nearComplete = 0
        for (r in 0 until GRID) {
            val filled = board[r].count { it != 0 }
            if (filled >= GRID - 1) nearComplete += filled
        }
        for (c in 0 until GRID) {
            val filled = (0 until GRID).count { board[it][c] != 0 }
            if (filled >= GRID - 1) nearComplete += filled
        }
        score += nearComplete * W_NEAR_COMPLETE

        // Bottom density (prefer filling bottom)
        var bottomDensity = 0
        for (r in GRID / 2 until GRID) {
            bottomDensity += board[r].count { it != 0 }
        }
        score += bottomDensity * W_BOTTOM_DENSITY

        // Cells placed
        score += cellsPlaced * W_CELLS_PLACED

        return score
    }

    // Parse a bitmap region into an 8x8 binary grid
    // cellSize: pixel size of each cell in the captured image
    fun parseBoardFromPixels(pixels: IntArray, width: Int, height: Int): Array<IntArray> {
        val board = Array(GRID) { IntArray(GRID) }
        val cellW = width / GRID
        val cellH = height / GRID

        for (r in 0 until GRID) {
            for (c in 0 until GRID) {
                // Sample center pixel of cell
                val px = (c * cellW + cellW / 2).coerceAtMost(width - 1)
                val py = (r * cellH + cellH / 2).coerceAtMost(height - 1)
                val pixel = pixels[py * width + px]

                // Extract RGB
                val red   = (pixel shr 16) and 0xFF
                val green = (pixel shr 8) and 0xFF
                val blue  = pixel and 0xFF

                // A cell is "filled" if it's not dark (empty cells are dark)
                val brightness = (red + green + blue) / 3
                board[r][c] = if (brightness > 60) 1 else 0
            }
        }
        return board
    }
}

package com.blockblastai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.nio.ByteBuffer

class ScreenCaptureManager(
    private val context: Context,
    private val mediaProjection: MediaProjection
) {

    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private val handler = Handler(Looper.getMainLooper())

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    // Estimated grid region (will be calibrated)
    // Block Blast grid typically occupies the center-upper portion of the screen
    data class GridRegion(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int,
        val cellSize: Int
    )

    init {
        val metrics = DisplayMetrics()
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    fun start() {
        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight,
            PixelFormat.RGBA_8888, 2
        )

        virtualDisplay = mediaProjection.createVirtualDisplay(
            "BlockBlastCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null
        )
    }

    fun stop() {
        virtualDisplay?.release()
        imageReader?.close()
        virtualDisplay = null
        imageReader = null
    }

    /**
     * Capture current screen and return as Bitmap
     */
    fun captureScreen(): Bitmap? {
        val reader = imageReader ?: return null
        val image: Image = reader.acquireLatestImage() ?: return null

        return try {
            val planes = image.planes
            val buffer: ByteBuffer = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride = planes[0].rowStride
            val rowPadding = rowStride - pixelStride * screenWidth

            val bitmap = Bitmap.createBitmap(
                screenWidth + rowPadding / pixelStride,
                screenHeight,
                Bitmap.Config.ARGB_8888
            )
            bitmap.copyPixelsFromBuffer(buffer)

            // Crop to actual screen width
            Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
        } finally {
            image.close()
        }
    }

    /**
     * Estimate grid region based on screen dimensions.
     * Block Blast typically has the grid in center, 
     * occupying about 80% of width, starting at ~15% from top.
     */
    fun estimateGridRegion(): GridRegion {
        val gridWidth = (screenWidth * 0.90).toInt()
        val left = (screenWidth - gridWidth) / 2
        val top = (screenHeight * 0.12).toInt()
        val right = left + gridWidth
        val bottom = top + gridWidth  // Square grid
        val cellSize = gridWidth / 8

        return GridRegion(left, top, right, bottom, cellSize)
    }

    /**
     * Parse the game board from a screenshot bitmap
     */
    fun parseBoardFromBitmap(bitmap: Bitmap, region: GridRegion): Array<IntArray> {
        val board = Array(8) { IntArray(8) }
        val gridBitmap = Bitmap.createBitmap(
            bitmap,
            region.left.coerceAtLeast(0),
            region.top.coerceAtLeast(0),
            (region.right - region.left).coerceAtMost(bitmap.width - region.left),
            (region.bottom - region.top).coerceAtMost(bitmap.height - region.top)
        )

        val w = gridBitmap.width
        val h = gridBitmap.height
        val pixels = IntArray(w * h)
        gridBitmap.getPixels(pixels, 0, w, 0, 0, w, h)

        val parsedBoard = AIEngine.parseBoardFromPixels(pixels, w, h)
        gridBitmap.recycle()
        return parsedBoard
    }

    /**
     * Convert grid cell (row, col) to screen coordinates for gesture
     */
    fun cellToScreenCoords(row: Int, col: Int, region: GridRegion): Pair<Float, Float> {
        val x = region.left + col * region.cellSize + region.cellSize / 2f
        val y = region.top + row * region.cellSize + region.cellSize / 2f
        return Pair(x, y)
    }

    /**
     * Estimate piece selector positions (bottom of screen)
     * Block Blast shows 3 pieces at the bottom
     */
    fun getPieceSelectorPositions(): List<Pair<Float, Float>> {
        val y = screenHeight * 0.82f
        return listOf(
            Pair(screenWidth * 0.18f, y),
            Pair(screenWidth * 0.50f, y),
            Pair(screenWidth * 0.82f, y)
        )
    }
}

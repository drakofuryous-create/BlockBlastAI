# 📱 Block Blast AI — Guide d'installation complet

## Ce que fait l'application

- **Détecte automatiquement** quand tu ouvres Block Blast
- **Affiche un panneau flottant** par-dessus le jeu (déplaçable)
- **Capture et analyse** la grille en temps réel
- **Joue automatiquement** en simulant des gestes de drag
- **Contrôle de vitesse** : de lent (visible) à ultra-rapide

---

## Prérequis

- Android 8.0 ou supérieur
- Android Studio (gratuit) : https://developer.android.com/studio
- Java 17 (inclus dans Android Studio)
- Block Blast installé sur ton téléphone

---

## ÉTAPE 1 — Installer Android Studio

1. Télécharge Android Studio sur https://developer.android.com/studio
2. Installe-le et lance-le
3. Lors du premier lancement, laisse-le télécharger le SDK Android (peut prendre 10-20 min)

---

## ÉTAPE 2 — Ouvrir le projet

1. Lance Android Studio
2. Clique sur **"Open"**
3. Sélectionne le dossier `BlockBlastAI`
4. Attends que Gradle synchronise (barre de progression en bas)

---

## ÉTAPE 3 — Activer le mode développeur sur ton téléphone

1. Va dans **Paramètres → À propos du téléphone**
2. Appuie **7 fois** sur **"Numéro de build"**
3. Un message "Vous êtes développeur !" apparaît
4. Va dans **Paramètres → Options développeur**
5. Active **"Débogage USB"**

---

## ÉTAPE 4 — Connecter ton téléphone

1. Connecte ton téléphone au PC via **câble USB**
2. Sur le téléphone, accepte le popup "Autoriser le débogage USB"
3. Dans Android Studio, en haut, ton téléphone doit apparaître dans la liste des appareils

---

## ÉTAPE 5 — Lancer l'application

1. Dans Android Studio, clique sur le bouton **▶ Run** (triangle vert)
2. Sélectionne ton téléphone
3. L'application s'installe et se lance automatiquement

---

## ÉTAPE 6 — Configurer les permissions (dans l'app)

L'app affiche 3 étapes à valider :

### Étape 1 : Accessibilité
1. Appuie sur **"ACTIVER"**
2. Va dans Accessibilité → Services installés → **Block Blast AI**
3. Active le service
4. Reviens dans l'app

### Étape 2 : Overlay
1. Appuie sur **"ACTIVER"**
2. Autorise l'affichage par-dessus les autres apps
3. Reviens dans l'app

### Étape 3 : Capture d'écran
1. Appuie sur **"ACTIVER"**
2. Accepte la capture d'écran dans le popup Android

---

## ÉTAPE 7 — Lancer l'AI

1. Toutes les étapes sont vertes ✓
2. Appuie sur **"▶ LANCER L'AI SUR BLOCK BLAST"**
3. **Ouvre Block Blast sur ton téléphone**
4. Le panneau de contrôle apparaît automatiquement sur le jeu !

---

## Utiliser le panneau de contrôle

```
┌─────────────────┐
│ ⣿ AI         ✕ │  ← appui ✕ pour fermer
│ ● ANALYSE...    │  ← statut en temps réel
│ COUPS    42     │
│ LIGNES   18     │
│ VITESSE  ══○══  │  ← ajuste la vitesse
│ [▶ JOUER]       │  ← lance/pause l'AI
│ → Cellule (3,4) │  ← prochain coup
└─────────────────┘
```

- **Déplace** le panneau en glissant la barre du haut
- **Vitesse** : à gauche = lent (tu vois les coups), à droite = rapide
- **Pause/Reprendre** à tout moment

---

## Dépannage

| Problème | Solution |
|----------|----------|
| Le panneau n'apparaît pas | Vérifie que le service d'accessibilité est actif |
| L'AI ne clique pas | Revérifie les permissions d'accessibilité |
| Crash au démarrage | Assure-toi d'avoir accepté la capture d'écran |
| "Gradle sync failed" | File → Sync Project with Gradle Files |
| Téléphone non détecté | Réessaie le câble USB, réactive le débogage USB |

---

## Note sur le package Block Blast

Le package ID de Block Blast utilisé est : `com.tge.blockspu`

Si ton version a un ID différent, modifie cette ligne dans :
`app/src/main/res/xml/accessibility_service_config.xml`
```xml
android:packageNames="com.tge.blockspu"
```
Et dans `BlockBlastAccessibilityService.kt` :
```kotlin
const val BLOCK_BLAST_PACKAGE = "com.tge.blockspu"
```

Pour trouver le bon package ID : dans le Play Store, l'URL contient `id=PACKAGE_ID`.

---

## Architecture technique

```
MainActivity.kt          — Interface setup + gestion permissions
BlockBlastAccessibilityService.kt — Détecte Block Blast + simule les gestes
OverlayService.kt        — Service foreground + panneau flottant
ScreenCaptureManager.kt  — Capture écran + analyse pixels grille
AIEngine.kt              — Algorithme AI (heuristique multi-critères)
```

---

*Block Blast AI v1.0 — Projet open source*
